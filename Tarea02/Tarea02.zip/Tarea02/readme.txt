Implementar los metodos señalados en las clases. 
Hacer uso de metodos auxiliares para que su codigo no quede tan feo.
Comentar. 

En la clase AVLTree implementar los 2 metodos de hasta abajo, usar auxiliares si quieren, 

el uso es el mismo

	java SweepLine < input.txt

con input.txt debe tener como primera linea el numero N de segmentos y despues
N lineas con segmentos en el formato x1 y1 x2 y2 que significa (x1,y1) (x2,y2)

ejemplo

3
1 1 5 5
3 4 5 6
7 8 9 10   

Cualquier duda me la hacen saber en el laboratorio ya que por correo seria mas dificil hacerme explicar pero igual por correo si quieren.

Y hacer uso del print del arbol, enserio ayuda demasiado.

Cualquier comentario o error de la practia hacermelo saber.
a mi con esta estructura me funciona el barrido de linea.